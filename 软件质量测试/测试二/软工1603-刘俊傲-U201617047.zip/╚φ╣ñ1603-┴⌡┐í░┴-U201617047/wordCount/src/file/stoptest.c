public static void test(){
   if(out == 3){
            file = 100;
            System.out.println(file);
   }
   else if(out == 1){
            file = files[0];
   }
}